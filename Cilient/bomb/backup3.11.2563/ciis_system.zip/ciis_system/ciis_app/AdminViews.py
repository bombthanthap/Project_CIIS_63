from django.contrib import messages
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import redirect, render
from django.urls import reverse
from ciis_app.models import *
from ciis_app.resource import DataCIISResource
from tablib.core import Dataset


def admin_home(request):
    return render(request,"admin_templates/base_template.html")
def add_financial(request):
    return render(request,"admin_templates/add_financial.html")



def add_admin(request):
    return render(request,"admin_templates/add_admin.html")


def add_admin_save(request):
    if request.method!="POST":
        return HttpResponse("Method Not Allowed")
    else:
        first_name=request.POST.get("first_name")
        last_name=request.POST.get("last_name")
        email=request.POST.get("email")
        password=request.POST.get("password")
        
        try:
            user=CustomUser.objects.create_user(username=email,password=password,email=email,last_name=last_name,first_name=first_name,user_type=1)
            
        except:
            messages.error(request,"Failed to Add Admin")
            return HttpResponseRedirect(reverse("add_admin"))
        else:
            user.save()
            messages.success(request,"Successfully Added Admin")
            return HttpResponseRedirect(reverse("staff_account"))


def add_financial_save(request):
    if request.method!="POST":
        return HttpResponse("Method Not Allowed")
    else:
        first_name=request.POST.get("first_name")
        last_name=request.POST.get("last_name")
        email=request.POST.get("email")
        password=request.POST.get("password")
        address=request.POST.get("address")
        try:
            user=CustomUser.objects.create_user(username=email,password=password,email=email,last_name=last_name,first_name=first_name,user_type=2)
            user.financials.address=address
            user.save()
            messages.success(request,"Successfully Added Financial")
            return HttpResponseRedirect(reverse("staff_account"))
        except:
            messages.error(request,"Failed to Add Financial")
            return HttpResponseRedirect(reverse("add_financial"))



def staff_account(request):
    financials=Financials.objects.all()
    adminciis=AdminCIIS.objects.all()
    return render(request,"admin_templates/staff_account.html",{"financials":financials,"adminciis":adminciis})

def edit_financial(request,financial_id):
    financial=Financials.objects.get(admin=financial_id)
    return render(request,"admin_templates/edit_financial.html",{"financial":financial,"id":financial_id})



    
def edit_financial_save(request,financial_id):
    if request.method!="POST":
        return HttpResponse("<h2>Method Not Allowed</h2>")
    else:
        first_name=request.POST.get("first_name")
        last_name=request.POST.get("last_name")
        email=request.POST.get("email")
        address=request.POST.get("address")

        try:
            user=CustomUser.objects.get(id=financial_id)
            user.first_name=first_name
            user.last_name=last_name
            user.email=email
            user.username=email
            user.save()
            
            financial_model=Financials.objects.get(admin=financial_id)
            financial_model.address=address
            financial_model.save()
            messages.success(request,"Successfully Edited Financial")
            return HttpResponseRedirect(reverse("edit_financial",kwargs={"financial_id":financial_id}))
        except:
            messages.error(request,"Failed to Edit Financial")
            return HttpResponseRedirect(reverse("edit_financial",kwargs={"financial_id":financial_id}))

def export(request):
    dataciis_resource = DataCIISResource()
    dataset = dataciis_resource.export()
    response = HttpResponse(dataset.xls, content_type='application/vnd.ms-excel')
    response['Content-Disposition'] = 'attachment; filename="tbl1.xls"'
    return response

def simple_upload(request):
    dataciis=DataCIIS.objects.all()
    if request.method == 'POST':
        dataciis_resource = DataCIISResource()
        dataset = Dataset()
        new_dataciis = request.FILES['myfile']
        
        imported_data = dataset.load(new_dataciis.read(),format='xlsx')
        print(imported_data)
        for data in imported_data:
        	value = DataCIIS(
        		data[0],
        		data[1],
        		 data[2],
        		 data[3],
                 data[4],
                 data[5]
        		)
        	value.save() 
    return render(request, "admin_templates/manages.html",{"dataciis":dataciis})



def edit_dataciis(request,dataciis_id):
    dataciis=DataCIIS.objects.get(id=dataciis_id)
    return render(request,"admin_templates/edit_dataciis.html",{"dataciis":dataciis,"id":dataciis_id})




def edit_dataciis_save(request,dataciis_id):
    if request.method!="POST":
        return HttpResponse("<h2>Method Not Allowed</h2>")
    else:
        paper_id=request.POST.get("paper_id")
        email=request.POST.get("email")
        paper_title=request.POST.get("paper_title")
        paper_type=request.POST.get("paper_type")
        author_name=request.POST.get("author_name")
        try:
            data=DataCIIS.objects.get(id=dataciis_id)
            data.paper_id=paper_id
            data.author_email=email
            data.paper_title=paper_title
            data.author_name=author_name
            data.save()
        
            messages.success(request,"Successfully")
            return HttpResponseRedirect(reverse("edit_dataciis",kwargs={"dataciis_id":dataciis_id}))
        except:
            messages.error(request,"Failed")
            return HttpResponseRedirect(reverse("edit_dataciis",kwargs={"dataciis_id":dataciis_id}))












def add_author(request):
    return render(request,"admin_templates/add_author.html")
def register_save_admin(request):
     if request.method!="POST":
            return HttpResponse("Method Not Allowed")
     else:
        title=request.POST.get("title")
        first_name=request.POST.get("first_name")
        last_name=request.POST.get("last_name")
        phone_number=request.POST.get("phoneNum")
        passport_id=request.POST.get("ppID")
        affiliation=request.POST.get("affiliation")
        country=request.POST.get("contrys")
        nationality=request.POST.get("nationality")
        status=request.POST.get("drone")
        email=request.POST.get("email")
        password=request.POST.get("password")
        cpassword=request.POST.get("cpassword")

        try:
            
                
           
            if country == "thai":
                status = "authorthai"
                    

            else:
                status = "authorforeigner"
                    

            
            user = CustomUser.objects.create_user(username=email,password=password,email=email,last_name=last_name,first_name=first_name,user_type=3)
            
           
            user.authors.phoneno=phone_number
            user.authors.passportid=passport_id
            user.authors.affiliation=affiliation
            user.authors.country=country
            user.authors.nationality=nationality
            user.authors.status=status
            

            user.save()

            
            
        except Exception as e :
            print(e)
            
            messages.error(request,"Failed")
            return HttpResponseRedirect(reverse("add_author"))
        else:
            user.save()
            messages.success(request,"Successfully Added Author")
            return HttpResponseRedirect(reverse("member_account"))

def member_regular(request):
    member=Authors.objects.filter(status="authorthai")
    return render(request,"admin_templates/manage_member_thai.html",{"member":member})


def exhibitors(request):
    regular=Paymentpaper.objects.filter(status="Success" ,author_type="Regular")
    virtual=Paymentpaper.objects.filter(status="Success",author_type="Virtual")
    return render(request,"admin_templates/exhibitors.html",{"regular":regular,"virtual":virtual})
    
def member_account(request):
    author=Authors.objects.all()
    participant=Participants.objects.all()
    return render(request,"admin_templates/member_account.html",{"author":author,"participant":participant})

def manage_owners(request):
    paper=paperauthor.objects.all()
    return render(request,"admin_templates/manage_owners.html",{"paper":paper})

def cancel_owners(request, id):
    obj = paperauthor.objects.get(pk = id)
    obj.delete()
    messages.success(request,"Cancel Success")
    return redirect('manage_owners')

def member_upgrade(request):
    member=CustomUser.objects.filter(user_type="4")
    return render(request,"admin_templates/member_upgrade.html",{"member":member})

def member_downgrade(request):
    member=CustomUser.objects.filter(user_type="4")
    return render(request,"admin_templates/member_downgrade.html",{"member":member})



