from django.apps import AppConfig


class CiisAppConfig(AppConfig):
    name = 'ciis_app'
