from django.contrib import messages
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from django.urls import reverse
from ciis_app.models import CustomUser


def participant_home(request):
    return render(request,"participant_templates/participant_home.html")

def participant_payment_history(request):
    return render(request,"participant_templates/participant_payment_history.html")

def participant_payment_re(request):
    return render(request,"participant_templates/participant_payment_re.html")

def participant_upload_bill(request):
    return render(request,"participant_templates/participant_upload_bill.html")

def participant_editinfomation(request):
    return render(request,"participant_templates/participant_editinfomation.html")

