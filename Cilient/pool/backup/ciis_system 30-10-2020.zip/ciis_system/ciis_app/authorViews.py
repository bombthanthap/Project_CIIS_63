from django.contrib import messages
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from django.urls import reverse
from ciis_app.models import *

def author_home(request):
    return render(request,"author_templates/author_home.html")

def author_add_paperid(request):
    data = paperauthor.object.all()
    return render(request,"author_templates/author_add_paperid.html",{"data":data})   

def author_payment_history(request):
    return render(request,"author_templates/author_payment_history.html")

def author_choose_paper(request):
    return render(request,"author_templates/author_choose_paper.html")

def author_upload_payment(request):
    return render(request,"author_templates/author_upload_payment.html")

def author_change_status(request):
    return render(request,"author_templates/author_change_status.html")

def author_edit_infomation(request):
    return render(request,"author_templates/author_edit_infomation.html")

def author_addpaperid_save(request):
    if request.method!="POST":
        return HttpResponse("Method Not Allowed")
    else:
        paperid=request.POST.get("PaperID")
        papertitle=request.POST.get("PaperTitle")
        data=DataCIIS.objects.all()
                
        try:
            for i in data:
                if paperid == i.paper_id and papertitle == i.paper_title:
                    paper_type="tttt"
                    status="tttt"
                    regis=paperauthor(paper_id=paperid,paper_title=papertitle,paper_type=paper_type,status=status)
                    regis.save()
                    return HttpResponseRedirect(reverse("author_add_paperid"))
            raise ValueError()

        except ValueError:
            return HttpResponseRedirect(reverse("author_add_paperid"))
        except:
            return HttpResponseRedirect(reverse("author_add_paperid"))


        

                    


            




