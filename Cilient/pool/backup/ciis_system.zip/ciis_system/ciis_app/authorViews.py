from django.contrib import messages
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from django.urls import reverse
from ciis_app.models import CustomUser

def author_home(request):
    return render(request,"author_templates/author_home.html")

def author_add_paperid(request):
    return render(request,"author_templates/author_add_paperid.html")    

def author_payment_history(request):
    return render(request,"author_templates/author_payment_history.html")

def author_choose_paper(request):
    return render(request,"author_templates/author_choose_paper.html")

def author_upload_payment(request):
    return render(request,"author_templates/author_upload_payment.html")

def author_change_status(request):
    return render(request,"author_templates/author_change_status.html")

def author_edit_infomation(request):
    return render(request,"author_templates/author_edit_infomation.html")