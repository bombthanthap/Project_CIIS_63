from django.contrib import messages
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from django.urls import reverse
from ciis_app.models import CustomUser

def auther_home(request):
    return render(request,"author_templates/auther_home.html")

def auther_add_paperid(request):
    return render(request,"author_templates/auther_add_paperid.html")    

def auther_payment_history(request):
    return render(request,"author_templates/auther_payment_history.html")

def auther_choose_paper(request):
    return render(request,"author_templates/auther_choose_paper.html")

def auther_upload_payment(request):
    return render(request,"author_templates/auther_upload_payment.html")

def auther_change_status(request):
    return render(request,"author_templates/auther_change_status.html")

def auther_edit_infomation(request):
    return render(request,"author_templates/auther_edit_infomation.html")