from django.contrib import messages
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from django.urls import reverse
from ciis_app.models import CustomUser

def auther_home(request):
    return render(request,"author_templates/auther_home.html")

def addpaperid(request):
    return render(request,"author_templates/addpaperid.html")    

def payment_history(request):
    return render(request,"author_templates/payment_history.html")

def choose_paper(request):
    return render(request,"author_templates/choose_paper.html")

def upload_payment(request):
    return render(request,"author_templates/upload_payment.html")

def change_status(request):
    return render(request,"author_templates/change_status.html")


def editinfomation(request):
    return render(request,"author_templates/editinfomation.html")