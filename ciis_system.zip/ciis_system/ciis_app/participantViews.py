from django.contrib import messages
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from django.urls import reverse
from ciis_app.models import CustomUser


def participant_home(request):
    return render(request,"participant_templates/participant_home.html")
def payment_history(request):
    return render(request,"participant_templates/payment_history.html")
def payment_re(request):
    return render(request,"participant_templates/payment_re.html")
def upload_bill(request):
    return render(request,"participant_templates/upload_bill.html")